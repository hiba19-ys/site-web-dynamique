-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 05 oct. 2026 à 22:47
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`nom`, `prenom`, `password`) VALUES
('fadili', 'hiba', 'fdlhiba2008');

-- --------------------------------------------------------

--
-- Structure de la table `produit_caftan`
--

CREATE TABLE `produit_caftan` (
  `id` int(100) NOT NULL,
  `nom` varchar(100) NOT NULL DEFAULT 'CAFTAN',
  `prix` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit_caftan`
--

INSERT INTO `produit_caftan` (`id`, `nom`, `prix`, `image`) VALUES
(1, 'CAFTAN', 250, 'CAFTAN IMG/OIP (1).webp'),
(2, 'CAFTAN', 300, 'CAFTAN IMG /OIP (2).webp'),
(3, 'CAFTAN', 350, 'CAFTAN IMG /OIP (3).webp'),
(4, 'CAFTAN', 350, 'CAFTAN IMG /OIP (4).webp'),
(5, 'CAFTAN', 450, 'CAFTAN IMG /OIP (5).webp'),
(6, 'CAFTAN', 500, 'CAFTAN IMG /OIP (6).webp'),
(7, 'CAFTAN', 400, 'CAFTAN IMG /OIP (7).webp'),
(8, 'CAFTAN', 350, 'CAFTAN IMG /OIP (8).webp'),
(9, 'CAFTAN', 400, 'CAFTAN IMG /OIP (9).webp'),
(10, 'CAFTAN', 380, 'CAFTAN IMG /OIP (10).webp'),
(11, 'CAFTAN', 420, 'CAFTAN IMG /OIP (11).webp'),
(12, 'CAFTAN', 450, 'CAFTAN IMG /OIP (12).webp'),
(13, 'CAFTAN', 350, 'CAFTAN IMG /OIP (13).webp'),
(14, 'CAFTAN', 500, 'CAFTAN IMG /OIP (14).webp'),
(15, 'CAFTAN', 370, 'CAFTAN IMG /OIP (15).webp'),
(16, 'CAFTAN', 380, 'CAFTAN IMG /OIP (16).webp'),
(17, 'CAFTAN', 250, 'CAFTAN IMG /OIP (17).webp'),
(18, 'CAFTAN', 400, 'CAFTAN IMG /OIP (18).webp'),
(19, 'CAFTAN', 250, 'CAFTAN IMG /OIP (19).webp'),
(20, 'CAFTAN', 250, 'CAFTAN IMG /OIP (20).jpg');

-- --------------------------------------------------------

--
-- Structure de la table `produit_djellaba`
--

CREATE TABLE `produit_djellaba` (
  `id` int(100) NOT NULL,
  `nom` varchar(100) NOT NULL DEFAULT 'DJELLABA',
  `prix` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit_djellaba`
--

INSERT INTO `produit_djellaba` (`id`, `nom`, `prix`, `image`) VALUES
(1, 'DJELLABA', 350, 'DJELLABA IMG/OIP (1).webp'),
(2, 'DJELLABA', 300, 'DJELLABA IMG/OIP (2).jpg'),
(3, 'DJELLABA', 300, 'DJELLABA IMG/OIP (3).jpg'),
(4, 'DJELLABA', 420, 'DJELLABA IMG/OIP (4).jpg'),
(5, 'DJELLABA', 480, 'DJELLABA IMG/OIP (5).webp'),
(6, 'DJELLABA', 320, 'DJELLABA IMG/OIP (6).jpg'),
(7, 'DJELLABA', 300, 'DJELLABA IMG/OIP (7).jpg'),
(8, 'DJELLABA', 450, 'DJELLABA IMG/OIP (8).jpg'),
(9, 'DJELLABA', 500, 'DJELLABA IMG/OIP (9).jpg'),
(10, 'DJELLABA', 450, 'DJELLABA IMG/OIP (10).jpg'),
(11, 'DJELLABA', 400, 'DJELLABA IMG/OIP (11).webp'),
(12, 'DJELLABA', 400, 'DJELLABA IMG/OIP (12).jpg'),
(13, 'DJELLABA', 370, 'DJELLABA IMG/OIP (13).webp'),
(14, 'DJELLABA', 400, 'DJELLABA IMG/OIP (14)).jpg'),
(15, 'DJELLABA', 300, 'DJELLABA IMG/OIP (15).jpg'),
(16, 'DJELLABA', 300, 'DJELLABA IMG/OIP (16).jpg'),
(17, 'DJELLABA', 380, 'DJELLABA IMG/OIP (17).webp'),
(18, 'DJELLABA', 300, 'DJELLABA IMG/OIP (18).jpg'),
(19, 'DJELLABA', 400, 'DJELLABA IMG/OIP (19).jpg'),
(20, 'DJELLABA', 400, 'DJELLABA IMG/OIP (20).jpg');

-- --------------------------------------------------------

--
-- Structure de la table `produit_jabador`
--

CREATE TABLE `produit_jabador` (
  `id` int(100) NOT NULL,
  `nom` varchar(100) NOT NULL DEFAULT 'JABADOR',
  `prix` int(100) NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT 'JABADOR IMG/OIP (1).webp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit_jabador`
--

INSERT INTO `produit_jabador` (`id`, `nom`, `prix`, `image`) VALUES
(1, 'JABADOR', 350, 'JABADOR IMG/OIP (1).webp'),
(2, 'JABADOR', 370, 'JABADOR IMG/OIP (2).webp'),
(3, 'JABADOR', 390, 'JABADOR IMG/OIP (3).webp'),
(4, 'JABADOR', 400, 'JABADOR IMG/OIP (4).webp'),
(5, 'JABADOR', 600, 'JABADOR IMG/OIP (5).webp'),
(6, 'JABADOR', 430, 'JABADOR IMG/OIP (6).webp'),
(7, 'JABADOR', 320, 'JABADOR IMG/OIP (7).webp'),
(8, 'JABADOR', 550, 'JABADOR IMG/OIP (8).webp'),
(9, 'JABADOR', 430, 'JABADOR IMG/OIP (9).webp'),
(10, 'JABADOR', 500, 'JABADOR IMG/OIP (10).webp'),
(11, 'JABADOR', 450, 'JABADOR IMG/OIP (11)).webp'),
(12, 'JABADOR', 460, 'JABADOR IMG/OIP (12).webp'),
(13, 'JABADOR', 400, 'JABADOR IMG/OIP (13).webp'),
(14, 'JABADOR', 370, 'JABADOR IMG/OIP (14).webp'),
(15, 'JABADOR', 650, 'JABADOR IMG/OIP (15).webp'),
(16, 'JABADOR', 500, 'JABADOR IMG/OIP (16).webp'),
(17, 'JABADOR', 480, 'JABADOR IMG/OIP (17).webp'),
(18, 'JABADOR', 300, 'JABADOR IMG/OIP (18).webp'),
(19, 'JABADOR', 400, 'JABADOR IMG/OIP (19).webp'),
(20, 'JABADOR', 470, 'JABADOR IMG/OIP (20).webp');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `produit_caftan`
--
ALTER TABLE `produit_caftan`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produit_djellaba`
--
ALTER TABLE `produit_djellaba`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produit_jabador`
--
ALTER TABLE `produit_jabador`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `produit_caftan`
--
ALTER TABLE `produit_caftan`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `produit_djellaba`
--
ALTER TABLE `produit_djellaba`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `produit_jabador`
--
ALTER TABLE `produit_jabador`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
